# BlogCrawlers

各大博客爬虫，爬取并保存为 markdown 文件。

根据网址，匹配配置，爬取博客，保存至本地。

## 支持网站

- 51CTO blog.51cto.com
- CSDN blog.csdn.net
- 腾讯云 cloud.tencent.com
- 博客园 cnblogs.com
- 阿里云开发者社区 developer.aliyun.com
- 掘金 juejin.im
- 微信推文 mp.weixin.qq.com
- 开源中国 my.oschina.net
- 思否 segmentfault.com
- 脚本之家 www.jb51.net
- 简书 www.jianshu.com
- 知乎专栏 zhuanlan.zhihu.com
- 人人都是产品经理 www.woshipm.com
